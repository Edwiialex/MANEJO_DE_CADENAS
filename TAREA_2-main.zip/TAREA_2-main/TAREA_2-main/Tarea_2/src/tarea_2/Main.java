package tarea_2;
// @author brecinosm
public class Main {
    public static void main(String[] args) {  
        
        frm_principal frm = new frm_principal();
        frm.setVisible(true);
    }
}
